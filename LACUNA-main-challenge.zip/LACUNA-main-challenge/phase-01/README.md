# Phase 01 — Signal / Noise

Open `questions/01.md`, then `questions/02.md`. The packet is synthetic and
offline. Timestamps use UTC unless a row says otherwise. Treat a clock
correction as the amount to subtract from the displayed device clock.
