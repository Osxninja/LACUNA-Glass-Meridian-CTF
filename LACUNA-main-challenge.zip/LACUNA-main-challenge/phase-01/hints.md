# Graduated hints — Phase 01

## Q01
1. Put every row on the same UTC clock before comparing them.
2. A fast clock is subtracted; a slow clock is corrected in the other direction.
3. The three normalized readings agree to the second.

## Q02
1. The key comes from the timestamp, not from the source names.
2. Keep leading zeroes in HHMMSS; the key is six ASCII characters.
3. Repeat those six bytes and XOR each byte of the hex-decoded receipt.
