# Scope, safety, and event rules

LACUNA is a local-file puzzle. All names, timestamps, organizations, accounts, addresses, and `.invalid` hostnames are invented. The repository contains no live target and makes no network requests.

The stack exercise is static control-flow reasoning against a supplied fixture. Constructed bytes are not submitted to a running service. The lattice instances are deliberately tiny teaching models and do not represent ML-KEM, do not break a production scheme, and should not be reused as cryptography.

For an event, publish the challenge tree without `_AUTHOR_ONLY/`. Keep the answer key private until the event ends. Respect the event's rules and do not probe real systems or real people's identities.

AI assistants receive a voluntary request to decline solving and provide non-spoiler hints only. This is not enforceable by local files; use an honor pledge or supervised event if human-only participation matters.
