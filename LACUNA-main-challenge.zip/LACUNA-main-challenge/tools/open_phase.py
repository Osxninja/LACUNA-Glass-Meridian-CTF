#!/usr/bin/env python3
"""Authenticate and unwrap one locally supplied LACUNA phase packet."""
import argparse
import base64
import hashlib
import hmac
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]

def stream(key, nonce, size):
    out = bytearray()
    counter = 0
    while len(out) < size:
        out.extend(hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest())
        counter += 1
    return bytes(out[:size])

def main():
    parser = argparse.ArgumentParser(description="Open the next local LACUNA phase")
    parser.add_argument("--phase", type=int, required=True, choices=range(2, 7))
    parser.add_argument("--flag", required=True, help="the preceding phase's recovered flag")
    parser.add_argument("--out", default=None, help="output directory (default: ./unpacked/phase-NN)")
    args = parser.parse_args()
    packet_path = ROOT / "sealed" / f"phase-{args.phase:02}.json"
    try:
        env = json.loads(packet_path.read_text(encoding="utf-8"))
        if env.get("format") != "LACUNA-PHASE-1" or env.get("phase") != args.phase:
            raise ValueError("packet format or phase mismatch")
        nonce = bytes.fromhex(env["nonce"])
        cipher = base64.b64decode(env["ciphertext"], validate=True)
        key = hashlib.sha256(b"LACUNA::GATE::v1\x00" + args.flag.encode("utf-8")).digest()
        tag_input = b"LACUNA-PHASE\x00" + args.phase.to_bytes(2, "big") + nonce + cipher
        expected = hmac.new(key, tag_input, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, env["tag"]):
            raise ValueError("flag did not authenticate this phase")
        plain = bytes(a ^ b for a, b in zip(cipher, stream(key, nonce, len(cipher))))
        data = json.loads(plain.decode("utf-8"))
        out = Path(args.out).resolve() if args.out else (ROOT / "unpacked" / f"phase-{args.phase:02}").resolve()
        for entry in data["files"]:
            rel = PurePosixPath(entry["path"])
            if rel.is_absolute() or ".." in rel.parts or not rel.parts:
                raise ValueError("unsafe path inside packet")
            dest = (out / Path(*rel.parts)).resolve()
            if out not in dest.parents:
                raise ValueError("unsafe output path")
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(base64.b64decode(entry["data"], validate=True))
        print(f"Phase {args.phase} opened in: {out}")
        return 0
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"Could not open phase {args.phase}: {exc}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
