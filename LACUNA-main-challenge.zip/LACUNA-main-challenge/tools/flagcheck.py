#!/usr/bin/env python3
"""Check a recovered LACUNA flag without printing any expected answer."""
import argparse
import hashlib
import hmac

HASHES = {"1": "c49ab2c8f4a03a30056dc27d118ee647c5471654a9592b26bef7478685107b02", "2": "2c1bef538df6063e0cc2d1c1512f979697a08430327265a2efca0dc5da20e87a", "3": "6b424a1b086355616835fcca7f74e31942fa9777b54d9999055cbed8d2fc5167", "4": "128e2c6f7fbab1d2b43b85defebe26657ea8d080e91e3d6e90296f6ec1ef4700", "5": "1470a629fa75bae202120f270fb712c02ba2a31e42fb0e9551ffb74109a25103", "6": "8c0e3450914d0ecef25ae419b2d9c2ce487fe5ea06470cb130681746b43cfd59"}

def main():
    parser = argparse.ArgumentParser(description="Check one LACUNA gate flag")
    parser.add_argument("--phase", type=int, required=True, choices=range(1, 7))
    parser.add_argument("--flag", required=True)
    args = parser.parse_args()
    digest = hashlib.sha256(args.flag.encode("utf-8")).hexdigest()
    if hmac.compare_digest(digest, HASHES[str(args.phase)]):
        print(f"Phase {args.phase}: accepted")
        return 0
    print(f"Phase {args.phase}: not accepted")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
